// server/api/sujets/[id].get.ts
import { defineWrappedResponseHandler } from '~/server/utils/mysql'
import { getHeader, createError } from 'h3'
import jwt from 'jsonwebtoken'

const SECRET = process.env.JWT_SECRET!

export default defineWrappedResponseHandler(async (event) => {
  // 1) Vérifier le token
  const authHeader = getHeader(event, 'authorization')
  if (!authHeader) {
    throw createError({ statusCode: 401, statusMessage: 'Authorization header required' })
  }

  const token = authHeader.split(' ')[1]
  try {
    jwt.verify(token, SECRET)
  } catch {
    throw createError({ statusCode: 401, statusMessage: 'Invalid token' })
  }

  // 2) Récupérer l'identifiant du sujet
  const sujetId = Number(event.context.params?.id)
  if (!sujetId) {
    throw createError({ statusCode: 400, statusMessage: 'ID requis' })
  }

  const db = event.context.mysql

  // 3) Rechercher les informations du sujet
  const [rows] = await db.execute(
    `SELECT s.id, s.titre, u.login AS auteur, s.created_at
     FROM sujets s
     JOIN utilisateurs u ON s.user_id = u.id
     WHERE s.id = ?`,
    [sujetId]
  )

  if (!Array.isArray(rows) || rows.length === 0) {
    throw createError({ statusCode: 404, statusMessage: 'Sujet introuvable' })
  }

  return { sujet: rows[0] }
})
