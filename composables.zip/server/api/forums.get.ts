// server/api/forums.get.ts
import { defineWrappedResponseHandler } from '~/server/utils/mysql'

export default defineWrappedResponseHandler(async (event) => {
  console.log('[API] GET /api/forums', {
    params: event.context.params,
    query:  event.context.query
  })

  const db = event.context.mysql

  // simple list of all forums, ordered by creation date
  const [rows] = await db.execute<any[]>(
    'SELECT id, nom AS name, created_at FROM forums ORDER BY created_at DESC'
  )

  return { forums: rows }
})
