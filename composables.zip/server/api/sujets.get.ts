// server/api/sujets.get.ts
import { defineWrappedResponseHandler } from '~/server/utils/mysql'
import { getQuery, getHeader, createError } from 'h3'
import jwt from 'jsonwebtoken'

const SECRET = process.env.JWT_SECRET!

export default defineWrappedResponseHandler(async (event) => {
  // 1) Vérifier le token dans l'en-tête Authorization
  const authHeader = getHeader(event, 'authorization')
  if (!authHeader) {
    throw createError({ statusCode: 401, statusMessage: 'Authorization header required' })
  }

  const token = authHeader.split(' ')[1]
  try {
    jwt.verify(token, SECRET)
  } catch {
    throw createError({ statusCode: 401, statusMessage: 'Invalid token' })
  }

  // 2) Lire les paramètres
  const query = getQuery(event)
  const forumId = Number(query.forumId)
  const page = Number(query.page) || 1
  const pageSize = 10
  const offset = (page - 1) * pageSize

  if (!forumId) {
    throw createError({ statusCode: 400, statusMessage: 'forumId requis' })
  }

  const db = event.context.mysql

  // 3) Récupérer les sujets
  const [rows] = await db.execute(
    `SELECT s.id, s.titre, u.login AS auteur,
            (SELECT u2.login FROM messages m 
             JOIN utilisateurs u2 ON m.user_id = u2.id 
             WHERE m.sujet_id = s.id 
             ORDER BY m.created_at DESC LIMIT 1) AS dernierAuteur,
            (SELECT MAX(m.created_at) FROM messages m WHERE m.sujet_id = s.id) AS derniereDate
     FROM sujets s
     JOIN utilisateurs u ON s.user_id = u.id
     WHERE s.forum_id = ?
     ORDER BY s.updated_at DESC
     LIMIT ? OFFSET ?`,
    [forumId, pageSize, offset]
  )

  const [countResult] = await db.execute(
    'SELECT COUNT(*) as total FROM sujets WHERE forum_id = ?',
    [forumId]
  )
  const total = (countResult as any)[0].total
  const pages = Math.ceil(total / pageSize)

  return { sujets: rows, pages }
})
