// server/api/messages/[id].delete.ts
import { defineSQLHandler } from '~/server/utils/mysql'
import { createError }      from 'h3'

export default defineSQLHandler(async (event) => {
  const { id } = event.context.params
  const db      = event.context.mysql

  // проверка авторизации — при желании можно добавить
  if (!event.context.session.user) {
    throw createError({ statusCode: 401, statusMessage: 'Non autorisé' })
  }

  const [result] = await db.execute<any>(
    'DELETE FROM messages WHERE id = ?',
    [id]
  )

  // result.affectedRows можно проверить, действительно ли что-то удалилось
  return { success: true }
})
