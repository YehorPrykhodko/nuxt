import mysql from 'mysql2/promise'

// создаём пул один раз
const pool = mysql.createPool({
  host:     process.env.DB_HOST     || 'localhost',
  user:     process.env.DB_USER     || 'user',
  password: process.env.DB_PASSWORD || 'toto',
  database: process.env.DB_NAME     || 'forum',
  port:     +(process.env.DB_PORT   || 3306),
  connectionLimit: 10,
  waitForConnections: true,
  queueLimit: 0
})

export default pool
