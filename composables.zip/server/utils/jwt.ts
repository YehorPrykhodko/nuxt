// server/utils/jwt.ts
import jwt from 'jsonwebtoken'

// Можно вынести в `.env` при желании
const SECRET = 'SUPER_SECRET_KEY_CHANGE_ME'

export function generateJwt(payload: object): string {
  return jwt.sign(payload, SECRET, { expiresIn: '7d' })
}

export function verifyJwt(token: string): any {
  return jwt.verify(token, SECRET)
}